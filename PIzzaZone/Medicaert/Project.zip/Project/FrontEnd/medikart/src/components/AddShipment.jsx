import React from "react"
import Footer from "./Footer";
import Header from "./Header";



const AddShipment=()=>{

    return(
        <div>
            <Header></Header>
            <h1>Page Under Construction</h1>
            <Footer></Footer>
        </div>
    )

}
export default AddShipment;