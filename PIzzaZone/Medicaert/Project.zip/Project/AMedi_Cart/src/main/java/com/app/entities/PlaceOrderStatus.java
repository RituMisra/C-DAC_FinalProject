package com.app.entities;

public enum PlaceOrderStatus {
	ORDER_PLACED, ORDER_SHIPPED,
}
