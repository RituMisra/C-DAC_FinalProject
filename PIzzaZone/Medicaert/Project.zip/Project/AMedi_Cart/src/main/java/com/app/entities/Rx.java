package com.app.entities;

public enum Rx {
	RQ, NRQ;
}
