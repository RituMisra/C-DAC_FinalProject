package com.app.dto;

public enum UserRole {
	ROLE_ADMIN, ROLE_CUSTOMER, ROLE_SUPPLIER, ROLE_DELIVERYBOY;

}
